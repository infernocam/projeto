import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.namespace.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Código da atividade principal
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_old_testament -> {
                // Lógica para exibir a seção do Antigo Testamento
                return true
            }
            R.id.menu_new_testament -> {
                // Lógica para exibir a seção do Novo Testamento
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
